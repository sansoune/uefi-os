#pragma once
#include "../includes/stdint.h"

const char* toString(int num);
const char* hex_to_String(uint64_t value);