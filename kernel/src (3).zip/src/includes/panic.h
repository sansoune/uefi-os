#pragma once 

#include "stdint.h"
#include "stdio.h"

void Panic(const char* Message);