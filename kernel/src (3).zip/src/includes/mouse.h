#pragma once
#include "pic.h"
#include "stdio.h"

void init_mouse();